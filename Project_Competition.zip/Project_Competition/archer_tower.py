import pygame
from tower import Tower
import math
class ArcherTower(Tower):
    def __init__(self,x,y):
        super().__init__(x,y,1)
        self.pause=False
        self.imgs=self.load_img()
        self.range=200
        self.in_range=False
        self.price=[1000,1500,"MAX"]
        self.name='ArcherTower'
        self.x=x
        self.y=y
    def load_img(self):
        imgs=[]
        self.level
        for i in range(1,17):
            add_str=str(i)
            imgs.append(pygame.transform.scale(pygame.image.load(f"archerTower_imgs\\archerTower_L{self.level} ({add_str}).png"),(90,225)))
        return imgs
    def placement(self):
        surf = pygame.Surface((self.range * 4, self.range * 4), pygame.SRCALPHA, 32)
        pygame.draw.circle(surf,self.color_radius, (self.range, self.range), self.range, 0)
        win.blit(surf, (self.x+50-self.range, self.y+100-self.range))
    def draw(self,win):
        super().draw(win)
        if self.in_range and not self.moving and not self.pause:
            self.animationCount += 1
            if self.animationCount>=len(self.imgs):
                self.animationCount=0
        else:
            self.animationCount=0
        if self.selected or self.moving:
            surf = pygame.Surface((self.range * 4, self.range * 4), pygame.SRCALPHA, 32)
            pygame.draw.circle(surf,self.color_radius, (self.range, self.range), self.range, 0)
            win.blit(surf, (self.x+50-self.range, self.y+100-self.range))
    def attack(self,enemies):
        money=0
        self.in_range=False
        closestEnemy=[]
        for enemy in enemies:
            x=enemy.x
            y=enemy.y
            dis=math.sqrt((self.x-x)**2+(self.y-y)**2)
            if self.range>=dis:
                self.in_range=True
                closestEnemy.append(enemy)
        closestEnemy.sort(key=lambda x:x.x)
        if len(closestEnemy)>0:
            firstEnemy=closestEnemy[0]
            if self.animationCount==14:
                if firstEnemy.hit(self.damage):
                    money+=firstEnemy.money
                    enemies.remove(firstEnemy)             
        return money

        