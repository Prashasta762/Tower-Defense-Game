import pygame
from enemy import Enemy
imgs=[]
for i in range(1,21):
	add_str=str(i)
	imgs.append(pygame.image.load(f"skeleton_imgs\\skeleton ({add_str}).png"))
class Skeleton(Enemy):
	def __init__(self):
		super().__init__(90,90,40,20,0)
		self.name='skeleton'
		self.imgs=imgs[:]
		self.money=50
		self.max_health=2
		self.health=self.max_health