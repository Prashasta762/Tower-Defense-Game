import pygame
import math
import time
class Enemy:
  def __init__(self,height,width,neg_y,add_x,add_y):
    self.add_x=add_x
    self.add_y=add_y
    self.neg_y=neg_y
    self.width=width
    self.height=height
    self.animation_count=0
    self.path=[(6, 476), (14, 475), (23, 475), (30, 476), (40, 476), (51, 475), (61, 474), (74, 477), (83, 483), (93, 483), (103, 488), (115, 485), (123, 484), (132, 481), (142, 480), (150, 473), (164, 479), (169, 482), (174, 482), (186, 483), (198, 489), (208, 489), (224, 491), (232, 495), (245, 510), (261, 528), (267, 525), (279, 525), (293, 522), (312, 519), (319, 519), (337, 519), (351, 518), (379, 519), (382, 519), (394, 520), (404, 524), (436, 523), (416, 523), (448, 525), (455, 525), (466, 525), (484, 527), (497, 525), (522, 527), (540, 528), (559, 525), (583, 527), (601, 531), (630, 535), (646, 534), (672, 534), (677, 533), (695, 526), (700, 514), (714, 507), (735, 495), (749, 480), (758, 466), (769, 438), (770, 419), (771, 414), (771, 399), (771, 386), (760, 368), (749, 348), (737, 340), (722, 334), (699, 317), (686, 311), (650, 302), (666, 299), (635, 300), (609, 299), (582, 299), (575, 295), (562, 289), (549, 289), (531, 289), (511, 289), (495, 295), (490, 293), (474, 293), (455, 293), (443, 288), (426, 280), (412, 271), (395, 250), (393, 235), (391, 209), (402, 199), (404, 183), (410, 168), (418, 163), (431, 143), (446, 129), (459, 113), (469, 105), (483, 93), (501, 88), (517, 82), (524, 82), (546, 80), (561, 78), (577, 72), (599, 69), (617, 75), (627, 78), (638, 78), (662, 78), (679, 82), (691, 82), (702, 81), (713, 81), (746, 83), (728, 80), (763, 85), (774, 81), (786, 81), (802, 81), (819, 83), (840, 73), (856, 75), (870, 82), (897, 85), (909, 84), (927, 84), (942, 84), (958, 83), (982, 83), (1010, 89), (1026, 83), (1047, 86), (1060, 86), (1090, 96), (1104, 96), (1114, 96), (1135, 93), (1153, 89), (1160, 89), (1179, 85), (1194, 85), (2100,85)]    
    self.x=self.path[0][0]-80
    self.y=self.path[0][1]-self.neg_y
    self.selected=False
    self.health=1
    self.max_health=0
    self.img=None
    self.path_pos=0
    self.flip=False
    self.pos=[self.x,self.y]
  def draw(self,win):
    self.img=pygame.transform.scale(self.imgs[self.animation_count],(self.width,self.height))
    win.blit(self.img,(self.x,self.y))
    length = 50
    moveBy = length / self.max_health
    healthBar = moveBy * self.health
    pygame.draw.rect(win, (255,0,0), (self.x+self.add_x, self.y+self.add_y, length, 10), 0)
    pygame.draw.rect(win, (0, 255, 0), (self.x+self.add_x, self.y+self.add_y, healthBar, 10), 0)
  def collide(self,x,y):
    if x<self.x+self.width and x>= self.x:
      if y<self.y+self.height and y>= self.y:
        return True
    return False
  def move(self):
      self.animation_count+=1
      if self.animation_count+1>=len(self.imgs):
        self.animation_count=0
      if self.path_pos>=len(self.path)-1:
           x2, y2 = (1280, 80)
      else:
         x2, y2 = self.path[self.path_pos]
      self.x=x2-80
      self.y=y2-self.neg_y
      try:
        if self.path_pos==64 or self.path_pos==90:
          self.flip=True
          self.x-=10
          for i,img in enumerate(self.imgs):
            self.imgs[i] = pygame.transform.flip(img, True, False)
        else:
          self.flip=False
      except IndexError:
        pass
      self.path_pos+=1
  def hit(self,damage):
    self.health-=damage
    if self.health<=0:
      return True
    return False
