import pygame
from enemy import Enemy
imgs=[]
for i in range(1,21):
	add_str=str(i)
	imgs.append(pygame.image.load(f"mummy_imgs\\mummy ({add_str}).png"))
class Mummy(Enemy):
	def __init__(self):
		super().__init__(130,130,60,40,10)
		self.name='mummy'
		self.imgs=imgs[:]
		self.money=100		
		self.max_health=4
		self.health=self.max_health
