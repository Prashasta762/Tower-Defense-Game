import pygame
from game import Game
pygame.init()
img_start=pygame.transform.scale(pygame.image.load('menu_imgs\\start.png'),(300,300))
logo=pygame.image.load('menu_imgs\\logo.png')
class MainMenu:
    def __init__(self):
        self.width=1200
        self.height=700
        self.win=pygame.display.set_mode((self.width,self.height))
        self.bg=pygame.transform.scale(pygame.image.load('bg.png'),(self.width,self.height))
        self.button=(self.width/2-img_start.get_width()/2,350,img_start.get_width(),img_start.get_height())
    def run(self):
        run = True
        while run:
            pygame.init()
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    run = False
                x, y = pygame.mouse.get_pos()
                if event.type==pygame.MOUSEBUTTONDOWN:
                    if self.button[0]<=x<=self.button[0]+self.button[2]:
                            if self.button[1]<=y<=self.button[1]+self.button[3]:
                                g=Game(self.win)
                                g.run()
                                del g
            try:
                self.draw()
            except pygame.error:
                pass
        pygame.quit()
    def draw(self):
       self.win.blit(self.bg,(0,0))
       self.win.blit(img_start,(self.button[0],self.button[1]-50))
       self.win.blit(logo,(150,0))
       pygame.display.update()

