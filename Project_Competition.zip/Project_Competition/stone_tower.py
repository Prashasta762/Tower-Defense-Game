import pygame
from tower import Tower
import math
class StoneTower(Tower):
    def __init__(self,x,y):
      super().__init__(x,y,2)
      self.imgs=self.load_img()
      self.towerRange=250
      self.stoneRange=75
      self.in_TowerRange=False
      self.in_stoneRange=False
      self.price=[2000,3000,"MAX"]
      self.name='StoneTower'
      self.x=x
      self.y=y
      self.stone_x=None
      self.stone_y=None
      self.pause=False
    def load_img(self):
      imgs=[]
      for i in range(1,24):
          add_str=str(i)
          imgs.append(pygame.transform.scale(pygame.image.load(f"stoneTower_imgs\\stoneTower_L{self.level} ({add_str}).png"),(90,225)))
      return imgs
    def draw(self,win):
      super().draw(win)
      if self.in_TowerRange and not self.moving and not self.pause:
        self.animationCount += 1
        if self.animationCount>=len(self.imgs):
            self.animationCount=0
      else:
        self.animationCount=0
      if self.selected or self.moving:
        surf = pygame.Surface((self.towerRange * 4, self.towerRange * 4), pygame.SRCALPHA, 32)
        pygame.draw.circle(surf,self.color_radius, (self.towerRange, self.towerRange), self.towerRange, 0)
        win.blit(surf, (self.x+50-self.towerRange, self.y+100-self.towerRange))
    def placement(self):
        surf = pygame.Surface((self.towerRange * 4, self.towerRange * 4), pygame.SRCALPHA, 32)
        pygame.draw.circle(surf,self.color_radius, (self.towerRange, self.towerRange), self.towerRange, 0)
        win.blit(surf, (self.x+50-self.towerRange, self.y+100-self.towerRange))
    def attack(self,enemies):
        money=0
        self.in_TowerRange=False
        self.in_stoneRange=False
        closestEnemy=[]
        for enemy in enemies:
            x=enemy.x
            y=enemy.y
            tower_dis=math.sqrt((self.x-x)**2+(self.y-y)**2)
            if self.towerRange>=tower_dis:
                self.in_TowerRange=True
                closestEnemy.append(enemy)
        closestEnemy.sort(key=lambda x:x.x)
        if len(closestEnemy)>0:
            firstEnemy=closestEnemy[0]
            closest_firstEnemy=[firstEnemy]
            for enemy in enemies:
                self.stone_x=firstEnemy.x
                self.stone_y=firstEnemy.y
                stone_dis=math.sqrt((self.stone_x-enemy.x)**2+(self.stone_y-enemy.y)**2)
                if self.stoneRange>stone_dis:
                    closest_firstEnemy.append(enemy)
                    self.in_stoneRange=True
            if self.animationCount==22:
                for enemy in closest_firstEnemy:
                    if enemy.hit(self.damage):
                        money+=enemy.money
                       	try:
                          enemies.remove(enemy)
                        except ValueError:
                          pass
                        closest_firstEnemy.remove(enemy)
                    else:
                        enemy.path_pos-=10
                        if enemy.path_pos<=0:
                          enemy.path_pos=0
        return money
