import pygame
import math
from mummy import Mummy
from ork import Ork
from skeleton import Skeleton
from archer_tower import ArcherTower
from stone_tower import StoneTower
from fire_tower import FireTower
from random import choice,randrange
from time import time
from menu import TowerMenu,PauseButton
pygame.init()
pygame.font.init()
img_lives=pygame.transform.scale(pygame.image.load('lives.png'),(50,50))
img_money=pygame.transform.scale(pygame.image.load('money.png'),(50,50))
img_menu=pygame.transform.rotate(pygame.transform.scale(pygame.image.load('menu_imgs\\menu.png'),(500,150)),90)
img_archer=pygame.transform.scale(pygame.image.load('archerTower_imgs\\archerTower_L1 (1).png'),(50,125))
img_stone=pygame.transform.scale(pygame.image.load('stoneTower_imgs\\stoneTower_L1 (1).png'),(50,125))
img_fire=pygame.transform.scale(pygame.image.load('fireTower_imgs\\fireTower_L1  (1).png'),(50,125))
img_play=pygame.transform.scale(pygame.image.load('menu_imgs\\play.png'),(75,75))
img_pause=pygame.transform.scale(pygame.image.load('menu_imgs\\pause.png'),(75,75))
tower_names=['ArcherTower','StoneTower','FireTower']
waveEnemies=[Skeleton(),Mummy(),Ork()]
waves=[[20,0,0],[50,0,0],[100,0,0],[0,20,0],[0,50,0],[0,100,0],[0,0,20],[0,0,50],[0,0,100],[50,50,0],[50,0,50],[0,50,50],[50,30,20],[30,50,20],[20,30,50],[30,20,50],[100,100,100],[200,200,200]]
class Game:
    def __init__(self,win):
        self.timer=time()
        self.width=1200
        self.height=700
        self.win=win
        pygame.display.set_caption("Tower Defense Game Made by Prashasta Vaish")
        self.font=pygame.font.SysFont("algerian", 65)
        self.enemies=[]
        self.towers=[]
        self.lives=10
        self.money=1500
        self.bg=pygame.transform.scale(pygame.image.load('BG.png'),(self.width,self.height))
        self.clicks=[]
        self.selectedTower=None
        self.menu=TowerMenu(1150,300,img_menu)
        self.menu.add_button(img_archer,'ArcherTower',500)
        self.menu.add_button(img_stone,'StoneTower',1000)
        self.menu.add_button(img_fire,'FireTower',2000)
        self.movingObj=None
        self.wave=0
        self.PauseButton=PauseButton(img_play,img_pause,0,150)
        self.currentWave=waves[self.wave]
        self.pause=True
    def create_waves(self):
        if sum(self.currentWave)<=0:
            if len(self.enemies)<=0:
                self.wave+=1
                try:
                    self.currentWave=waves[self.wave]
                except IndexError:
                    self.wave-=1
                    currentWave=[]
                    for i in self.currentWave:
                        currentWave.append(i+100)
                    waves.append(currentWave)
                self.pause=True
                self.PauseButton.paused = self.pause
        else:
            waveEnemies=[Skeleton(),Mummy(),Ork()]
            for i in range(len(self.currentWave)):
                if self.currentWave[i]>=0:
                    self.enemies.append(waveEnemies[i])
                    self.currentWave[i]=self.currentWave[i]-1
                    break
    def run(self):
        run=True
        clock = pygame.time.Clock()
        while run:
            clock.tick(200)
            if not self.pause:
                if time()-self.timer>0.2:
                    self.timer=time()
                    self.create_waves()
            pos=pygame.mouse.get_pos()
            if self.movingObj:
                collide=False
                self.movingObj.move(pos[0]-self.movingObj.img.get_width()/2,pos[1]-self.movingObj.img.get_height()/2)
                for tower in self.towers:
                    if tower.collide(self.movingObj):
                        collide=True
                        self.movingObj.color_radius=(255,0,0,25)
                    elif self.movingObj.collide(tower):
                        collide=True
                        self.movingObj.color_radius=(255,0,0,25)
                    else:
                        if collide==False:
                            self.movingObj.color_radius=(0,0,128,25)
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    run=False
                if event.type==pygame.MOUSEBUTTONUP:
                    if self.movingObj:
                        allowed=True
                        for tower in self.towers:
                            if tower.collide(self.movingObj):
                                allowed=False
                        if allowed:
                            if self.movingObj.name in tower_names:
                                self.towers.append(self.movingObj)
                            self.movingObj.moving=False
                            self.movingObj=None
                    else:
                        if self.PauseButton.click(pos[0], pos[1]):
                            self.pause = not(self.pause)
                            self.PauseButton.paused = self.pause
                        towerButton_clicked=self.menu.clicked_item(pos[0],pos[1])
                        if towerButton_clicked:
                            cost = self.menu.item_cost(towerButton_clicked)
                            if self.money >= cost:
                                self.money -= cost
                                self.add_tower(towerButton_clicked)
                            else:
                                print('not enough money')
                        button_clicked = None
                        if self.selectedTower:
                            button_clicked = self.selectedTower.menu.clicked_item(pos[0], pos[1])
                            if button_clicked:
                                if button_clicked=="upgrade":
                                    cost = self.selectedTower.GetUpgradeCost()
                                    if cost!='MAX':
                                        if self.money>=cost:
                                            self.money-=cost
                                            self.selectedTower.upgrade()
                                            self.selectedTower.imgs=self.selectedTower.load_img()
                                        else:
                                            print('not enough money')    
                        if not button_clicked:
                            for tower in self.towers:
                                if tower.click(pos[0], pos[1]):
                                    tower.selected = True
                                    self.selectedTower = tower
                                else:
                                    tower.selected = False
            to_del=[]
            if not self.pause:
                for enemy in self.enemies:
                    enemy.move()
                    if enemy.path_pos>=143:
                        to_del.append(enemy)
                        self.lives-=1
                for i in to_del:
                    self.enemies.remove(i)
                    to_del.remove(i)
                for tower in self.towers:
                    self.money+=tower.attack(self.enemies)
                if self.lives <=0:
                        print('you have lost')
                        run = False
            self.draw()
        pygame.quit()
    def draw(self):
        self.win.blit(self.bg,(0,0))
        for enemy in self.enemies:
            enemy.draw(self.win)
        for tower in self.towers:
            tower.pause=self.pause
            tower.draw(self.win)
        if self.movingObj:
            self.movingObj.draw(self.win)
        self.menu.draw(self.win)
        text = self.font.render(str(self.lives),1,(255,255,255))
        x = self.width+img_lives.get_width()+10
        self.win.blit(text,(50,0))
        self.win.blit(img_lives,(0,10))
        text = self.font.render(str(self.money),1,(255, 255, 255))
        x=self.width+img_lives.get_width()+10
        self.win.blit(text,(50,60))
        self.win.blit(img_money,(0,65))
        self.PauseButton.draw(self.win)
        text=self.font.render('Wave '+str(self.wave+1),1,(255, 255, 255))
        self.win.blit(text,(85,145))
        pygame.display.update()
    def add_tower(self,name):
        x,y=pygame.mouse.get_pos()
        name_lst=['ArcherTower','StoneTower','FireTower']
        obj_lst=[ArcherTower(x,y),StoneTower(x,y),FireTower(x,y)]
        obj=obj_lst[name_lst.index(name)]
        obj.moving=True
        self.movingObj=obj

