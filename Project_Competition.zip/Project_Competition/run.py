import pygame
from main_menu import MainMenu
if __name__=='__main__':
    pygame.init()
    try:
    	main=MainMenu()
    	main.run()
    except pygame.error:
    	pass

