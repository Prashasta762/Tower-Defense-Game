import pygame
img_money=pygame.transform.scale(pygame.image.load('money.png'),(50,50))
class Button:
    def __init__(self,menu,img,name):
        self.img=img
        self.menu=menu
        self.name=name
        self.x=self.menu.x
        self.y=self.menu.y
        self.width = self.img.get_width()
        self.height = self.img.get_height()
    def draw(self, win):
        win.blit(self.img, (self.x, self.y+10))
    def click(self,x,y):
        if x<self.x+self.width and x>= self.x:
            if y<self.y+self.height and y>= self.y:
                return True
        return False
    def update(self):
        self.x = self.menu.x-10
        self.y = self.menu.y+160

class TowerButton(Button):
    def __init__(self,img,name,x,y,cost):
        self.name = name
        self.img = img
        self.x = x
        self.y = y
        self.width = self.img.get_width()
        self.height = self.img.get_height()
        self.cost = cost
class Menu:
    def __init__(self,x,y,img,tower):
        self.img=img
        self.x=x
        self.y=y
        self.width=img.get_width()
        self.height=img.get_height()
        self.buttons=[]
        self.items=0
        self.tower=tower
        self.font=pygame.font.SysFont("algerian",25)
    def add_button(self,img,name):
        self.items += 1
        self.buttons.append(Button(self,img,name))
    def clicked_item(self,x,y):
        for button in self.buttons:
            if button.click(x,y):
                return button.name
    def draw(self,win):
        win.blit(self.img,(self.x-20,self.y+150))
        for item in self.buttons:
            item.draw(win)
            win.blit(img_money,(item.x+item.width,item.y))
            text_upgrade=self.font.render(str(self.tower.price[self.tower.level-1]),1,(255,255,255))
            win.blit(text_upgrade,(item.x+item.width,item.y+img_money.get_height()))
    def update(self):
        for button in self.buttons:
            button.update()
class PauseButton(Button):
    def __init__(self,img_play,img_pause,x,y):
        self.play = img_play
        self.pause = img_pause
        self.img=img_play
        self.x = x
        self.y = y
        self.width = self.img.get_width()
        self.height = self.img.get_height()
        self.paused = True
    def draw(self, win):
        if self.paused:
            win.blit(self.play, (self.x, self.y))
        else:
            win.blit(self.pause, (self.x, self.y))
        
class TowerMenu(Menu):
    def __init__(self,x,y,img):
        self.img=img
        self.x=x
        self.y=y
        self.width=img.get_width()
        self.height=img.get_height()
        self.buttons=[]
        self.items=0
        self.font=pygame.font.SysFont("algerian",25)
    def item_cost(self,name):
        for button in self.buttons:
            if button.name == name:
                return button.cost
    def add_button(self,img,name,cost):
        self.items += 1
        button_x=self.x-10
        button_y=self.y-100 + (self.items-1)*120
        self.buttons.append(TowerButton(img,name,button_x,button_y,cost))
    def draw(self,win):
        win.blit(self.img, (self.x-self.img.get_width()/2,self.y-120))
        money_img=pygame.transform.scale(img_money,(20,20))
        for item in self.buttons:
            item.draw(win)
            win.blit(money_img,(item.x-25,item.y+item.height-10))
            text = self.font.render(str(item.cost),1,(255,255,255))
            win.blit(text,(item.x-10+item.width/2-text.get_width()/2+7,item.y+item.height-15))