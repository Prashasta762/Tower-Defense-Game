import pygame
import math
from menu import Menu
img_menu=pygame.transform.scale(pygame.image.load('menu_imgs\\menu.png'),(130,100))
img_upgrade=pygame.transform.scale(pygame.image.load('menu_imgs\\upgrade.png'),(57,57))
class Tower:
    def __init__(self,x,y,damage):
        self.x=x
        self.y=y
        self.level=1
        self.damage=damage
        self.width=90
        self.height=255
        self.animationCount=0
        self.selected=False
        self.menu=Menu(self.x,self.y,img_menu,self)
        self.menu.add_button(img_upgrade,"upgrade")
        self.moving=False
        self.img=None
        self.imgs=[]
        self.color_radius=(0, 0, 128, 25)
    def draw(self,win):
        self.img=self.imgs[self.animationCount].convert_alpha()
        if self.animationCount>=len(self.imgs)-1:
          self.animationCount=0
        self.animationCount+=1
        win.blit(self.img,(self.x,self.y))
        if self.selected:
            self.menu.draw(win)
    def click(self,x,y):
        if x<self.x+self.width and x>= self.x:
            if y<self.y+self.height and y>= self.y:
                return True
        return False
    def upgrade(self):
        if self.level<3:
            self.level+=1
            self.damage+=1
            return self.level,self.damage
    def GetUpgradeCost(self):
        return self.price[self.level-1]
    def move(self,x,y):
        self.x=x
        self.y=y
        self.menu.x=x
        self.menu.y=y
        self.menu.update()
    def collide(self,Tower):
        x=Tower.x
        y=Tower.y
        dis=math.sqrt((x - self.x)**2 + (y- self.y)**2)
        if dis<=100:
            return True 
        else:
            return False

        