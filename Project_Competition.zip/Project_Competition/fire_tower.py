import pygame
from tower import Tower
import math
class FireTower(Tower):
    def __init__(self,x,y):
      super().__init__(x,y,3)
      self.imgs=self.load_img()
      self.towerRange=250
      self.fireStoneRange=75
      self.in_TowerRange=False
      self.in_fireStoneRange=False
      self.price=[3000,4000,"MAX"]
      self.name='FireTower'
      self.x=x
      self.y=y
      self.fireStone_x=None
      self.fireStone_y=None
      self.pause=False
    def load_img(self):  
        imgs=[]
        for i in range(1,24):
          add_str=str(i)
          imgs.append(pygame.transform.scale(pygame.image.load(f"fireTower_imgs\\fireTower_L{self.level}  ({i}).png"),(90,225)))
        return imgs
    def draw(self,win):
      super().draw(win)
      if self.in_TowerRange and not self.moving and not self.pause:
        self.animationCount += 1
        if self.animationCount>=len(self.imgs):
            self.animationCount=0
      else:
        self.animationCount=0
      if self.selected or self.moving:  
        surf = pygame.Surface((self.towerRange * 4, self.towerRange * 4), pygame.SRCALPHA, 32)
        pygame.draw.circle(surf,self.color_radius, (self.towerRange, self.towerRange), self.towerRange, 0)
        win.blit(surf, (self.x+50-self.towerRange, self.y+100-self.towerRange))
    def placement(self):
        surf = pygame.Surface((self.towerRange * 4, self.towerRange * 4), pygame.SRCALPHA, 32)
        pygame.draw.circle(surf,self.color_radius, (self.towerRange, self.towerRange), self.towerRange, 0)
        win.blit(surf, (self.x+50-self.towerRange, self.y+100-self.towerRange))
    def attack(self,enemies):
        money=0
        self.in_TowerRange=False
        self.in_fireStoneRange=False
        closestEnemy=[]
        for enemy in enemies:
            x=enemy.x
            y=enemy.y
            tower_dis=math.sqrt((self.x-x)**2+(self.y-y)**2)
            if self.towerRange>=tower_dis:
                self.in_TowerRange=True
                closestEnemy.append(enemy)
        closestEnemy.sort(key=lambda x:x.x)
        if len(closestEnemy)>0:
            firstEnemy=closestEnemy[0]
            closest_firstEnemy=[firstEnemy]
            for enemy in enemies:
                self.fireStone_x=firstEnemy.x
                self.fireStone_y=firstEnemy.y
                fireStone_dis=math.sqrt((self.fireStone_x-enemy.x)**2+(self.fireStone_y-enemy.y)**2)
                if self.fireStoneRange>fireStone_dis:
                    closest_firstEnemy.append(enemy)
                    self.in_fireStoneRange=True
            if self.animationCount==22:
                for enemy in closest_firstEnemy:
                    if enemy.hit(self.damage):
                        money+=enemy.money
                        try:
                          enemies.remove(enemy)
                        except ValueError:
                          pass
                        closest_firstEnemy.remove(enemy)
                    else:
                        enemy.path_pos-=10
                        if enemy.path_pos<=0:
                          enemy.path_pos=0
        return money            