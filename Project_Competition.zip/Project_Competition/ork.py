import pygame
from enemy import Enemy
imgs=[]
for i in range(1,21):
	add_str=str(i)
	imgs.append(pygame.image.load(f"ork_imgs\\ork ({add_str}).png"))
class Ork(Enemy):
	def __init__(self):
		super().__init__(90,90,40,20,0)
		self.name='ork'
		self.imgs=imgs[:]
		self.money=150
		self.max_health=6
		self.health=self.max_health